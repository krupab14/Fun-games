﻿
Public Class Form3

    Dim checkforXorO As Boolean = False
    Dim addonetoscore As Integer = 0
    Sub buttonsenabledfalse()
        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False
        Button4.Enabled = False
        Button5.Enabled = False
        Button6.Enabled = False
        Button7.Enabled = False
        Button8.Enabled = False
        Button9.Enabled = False
    End Sub
    Sub checkforwin()
        If Button1.Text = "X" And Button2.Text = "X" And Button3.Text = "X" Then
            Button1.BackColor = Color.Fuchsia
            Button2.BackColor = Color.Fuchsia
            Button3.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button4.Text = "X" And Button5.Text = "X" And Button6.Text = "X" Then
            Button4.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button6.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button7.Text = "X" And Button8.Text = "X" And Button9.Text = "X" Then
            Button7.BackColor = Color.Fuchsia
            Button8.BackColor = Color.Fuchsia
            Button9.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button1.Text = "X" And Button4.Text = "X" And Button7.Text = "X" Then
            Button1.BackColor = Color.Fuchsia
            Button4.BackColor = Color.Fuchsia
            Button7.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button2.Text = "X" And Button5.Text = "X" And Button8.Text = "X" Then
            Button2.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button8.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button3.Text = "X" And Button6.Text = "X" And Button9.Text = "X" Then
            Button3.BackColor = Color.Fuchsia
            Button6.BackColor = Color.Fuchsia
            Button9.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button1.Text = "X" And Button5.Text = "X" And Button9.Text = "X" Then
            Button1.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button9.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button3.Text = "X" And Button5.Text = "X" And Button7.Text = "X" Then
            Button3.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button7.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player X", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        ' O combinationss
        If Button1.Text = "O" And Button2.Text = "O" And Button3.Text = "O" Then
            Button1.BackColor = Color.Fuchsia
            Button2.BackColor = Color.Fuchsia
            Button3.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player 0", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button4.Text = "O" And Button5.Text = "O" And Button6.Text = "O" Then
            Button4.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button6.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button7.Text = "O" And Button8.Text = "O" And Button9.Text = "O" Then
            Button7.BackColor = Color.Fuchsia
            Button8.BackColor = Color.Fuchsia
            Button9.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button1.Text = "O" And Button4.Text = "O" And Button7.Text = "O" Then
            Button1.BackColor = Color.Fuchsia
            Button4.BackColor = Color.Fuchsia
            Button7.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button2.Text = "O" And Button5.Text = "O" And Button8.Text = "O" Then
            Button2.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button8.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button3.Text = "O" And Button6.Text = "O" And Button9.Text = "O" Then
            Button3.BackColor = Color.Fuchsia
            Button6.BackColor = Color.Fuchsia
            Button9.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button1.Text = "O" And Button5.Text = "O" And Button9.Text = "O" Then
            Button1.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button9.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If
        If Button3.Text = "O" And Button5.Text = "O" And Button7.Text = "O" Then
            Button3.BackColor = Color.Fuchsia
            Button5.BackColor = Color.Fuchsia
            Button7.BackColor = Color.Fuchsia
            MessageBox.Show("Winner is Player O", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            buttonsenabledfalse()
        End If

    End Sub

    Private Sub button_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click, Button8.Click, Button7.Click, Button6.Click, Button5.Click, Button4.Click, Button3.Click, Button2.Click, Button1.Click
        Dim b As Button = sender
        If checkforXorO = False Then
            b.Text = "X"
            checkforXorO = True
        Else
            b.Text = "O"
            checkforXorO = False
        End If
        checkforwin()
        b.Enabled = False
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True

        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""

        Button1.BackColor = Color.DarkCyan
        Button2.BackColor = Color.DarkCyan
        Button3.BackColor = Color.DarkCyan
        Button4.BackColor = Color.DarkCyan
        Button5.BackColor = Color.DarkCyan
        Button6.BackColor = Color.DarkCyan
        Button7.BackColor = Color.DarkCyan
        Button8.BackColor = Color.DarkCyan
        Button9.BackColor = Color.DarkCyan



    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True

        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""

        Button1.BackColor = Color.DarkCyan
        Button2.BackColor = Color.DarkCyan
        Button3.BackColor = Color.DarkCyan
        Button4.BackColor = Color.DarkCyan
        Button5.BackColor = Color.DarkCyan
        Button6.BackColor = Color.DarkCyan
        Button7.BackColor = Color.DarkCyan
        Button8.BackColor = Color.DarkCyan
        Button9.BackColor = Color.DarkCyan


    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Dim checkforexit As DialogResult = MessageBox.Show("Please confirm your exit", "Tic Tac Toe", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If checkforexit = DialogResult.Yes Then
            Application.Exit()

        End If
    End Sub

 
End Class