﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Finish = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(6, -34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(837, 25)
        Me.Label1.TabIndex = 76
        Me.Label1.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(6, -2)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 195)
        Me.Label2.TabIndex = 77
        Me.Label2.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(427, 196)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 191)
        Me.Label4.TabIndex = 78
        Me.Label4.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(6, 242)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 245)
        Me.Label5.TabIndex = 79
        Me.Label5.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(762, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 304)
        Me.Label6.TabIndex = 80
        Me.Label6.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(828, -34)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 468)
        Me.Label8.TabIndex = 81
        Me.Label8.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(19, 462)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(792, 25)
        Me.Label3.TabIndex = 82
        Me.Label3.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Location = New System.Drawing.Point(6, 184)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(214, 25)
        Me.Label9.TabIndex = 83
        Me.Label9.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Location = New System.Drawing.Point(66, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(432, 25)
        Me.Label10.TabIndex = 84
        Me.Label10.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Location = New System.Drawing.Point(66, 32)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 136)
        Me.Label11.TabIndex = 85
        Me.Label11.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label12.Location = New System.Drawing.Point(258, 40)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(28, 156)
        Me.Label12.TabIndex = 86
        Me.Label12.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label13.Location = New System.Drawing.Point(192, 116)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(28, 93)
        Me.Label13.TabIndex = 87
        Me.Label13.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label14.Location = New System.Drawing.Point(135, 67)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 89)
        Me.Label14.TabIndex = 88
        Me.Label14.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label15.Location = New System.Drawing.Point(84, 209)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 125)
        Me.Label15.TabIndex = 89
        Me.Label15.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label16.Location = New System.Drawing.Point(84, 143)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(79, 25)
        Me.Label16.TabIndex = 90
        Me.Label16.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label17.Location = New System.Drawing.Point(258, 171)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(376, 25)
        Me.Label17.TabIndex = 91
        Me.Label17.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label18.Location = New System.Drawing.Point(427, 375)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(173, 25)
        Me.Label18.TabIndex = 92
        Me.Label18.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label19.Location = New System.Drawing.Point(111, 242)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(214, 25)
        Me.Label19.TabIndex = 93
        Me.Label19.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label20.Location = New System.Drawing.Point(297, 251)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(28, 73)
        Me.Label20.TabIndex = 94
        Me.Label20.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label21.Location = New System.Drawing.Point(297, 299)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(130, 25)
        Me.Label21.TabIndex = 95
        Me.Label21.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label22.Location = New System.Drawing.Point(31, 362)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(148, 25)
        Me.Label22.TabIndex = 96
        Me.Label22.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label23.Location = New System.Drawing.Point(151, 309)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(28, 77)
        Me.Label23.TabIndex = 97
        Me.Label23.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label24.Location = New System.Drawing.Point(151, 299)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(103, 25)
        Me.Label24.TabIndex = 98
        Me.Label24.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label25.Location = New System.Drawing.Point(226, 299)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(28, 125)
        Me.Label25.TabIndex = 99
        Me.Label25.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label26.Location = New System.Drawing.Point(84, 409)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(296, 25)
        Me.Label26.TabIndex = 100
        Me.Label26.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label27.Location = New System.Drawing.Point(645, -2)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(28, 90)
        Me.Label27.TabIndex = 101
        Me.Label27.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label28.Location = New System.Drawing.Point(317, 116)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(473, 25)
        Me.Label28.TabIndex = 102
        Me.Label28.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label29.Location = New System.Drawing.Point(551, 32)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(28, 84)
        Me.Label29.TabIndex = 103
        Me.Label29.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label30.Location = New System.Drawing.Point(671, 209)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(119, 25)
        Me.Label30.TabIndex = 104
        Me.Label30.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label31.Location = New System.Drawing.Point(647, 209)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(28, 191)
        Me.Label31.TabIndex = 105
        Me.Label31.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label32.Location = New System.Drawing.Point(665, 375)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(125, 25)
        Me.Label32.TabIndex = 106
        Me.Label32.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label33.Location = New System.Drawing.Point(762, 375)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(28, 59)
        Me.Label33.TabIndex = 107
        Me.Label33.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(538, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 135)
        Me.Label7.TabIndex = 108
        Me.Label7.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label34.Location = New System.Drawing.Point(487, 319)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(79, 25)
        Me.Label34.TabIndex = 109
        Me.Label34.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label35.Location = New System.Drawing.Point(487, 233)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(28, 89)
        Me.Label35.TabIndex = 110
        Me.Label35.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label36.Location = New System.Drawing.Point(84, 63)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(79, 25)
        Me.Label36.TabIndex = 111
        Me.Label36.Text = "Label1 nggggbleeeeeeeeeeeeeeeeeeeeh"
        '
        'Finish
        '
        Me.Finish.AutoSize = True
        Me.Finish.Location = New System.Drawing.Point(817, 474)
        Me.Finish.Name = "Finish"
        Me.Finish.Size = New System.Drawing.Size(34, 13)
        Me.Finish.TabIndex = 112
        Me.Finish.Text = "Finish"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkCyan
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Finish)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(114, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(864, 503)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DarkCyan
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(12, 46)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(96, 99)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DarkCyan
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(12, 198)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(96, 100)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Restart"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(990, 524)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.Text = "Maze Game"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Finish As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button

End Class
